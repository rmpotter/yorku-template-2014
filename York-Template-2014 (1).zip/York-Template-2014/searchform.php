<form role="search" method="get" class="search-form" action="<?php echo home_url( '/' ); ?>">
<label for="s" class="accessible">Search</label>
<input id="s" type="search" class="header-search" placeholder="" value="Search this site" name="s" title="Search for:">
<button type="submit" class="search-button-icon"  onclick="submit();"> <div class="icon-search icon-medium"></div><span class="accessible">site search button</span></button>
</form>
