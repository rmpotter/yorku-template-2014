<?php
$theme_path = get_stylesheet_directory_uri();

//$options = get_option('YU_twentyeleven_theme_options');

$options = get_option('york_twentythirteen_options');

// Load up our theme options page and related code.
//require( dirname( __FILE__ ) . '/admin-includes/theme-options.php' );

/**
 * Twenty Thirteen functions and definitions.
 *
 * Sets up the theme and provides some helper functions, which are used in the
 * theme as custom template tags. Others are attached to action and filter
 * hooks in WordPress to change core functionality.
 *
 * When using a child theme (see http://codex.wordpress.org/Theme_Development
 * and http://codex.wordpress.org/Child_Themes), you can override certain
 * functions (those wrapped in a function_exists() call) by defining them first
 * in your child theme's functions.php file. The child theme's functions.php
 * file is included before the parent theme's file, so the child theme
 * functions would be used.
 *
 * Functions that are not pluggable (not wrapped in function_exists()) are
 * instead attached to a filter or action hook.
 *
 * For more information on hooks, actions, and filters,
 * see http://codex.wordpress.org/Plugin_API
 *
 * @package WordPress
 * @subpackage Twenty_Thirteen
 * @since Twenty Thirteen 1.0
 */

wp_oembed_add_provider( '/https?:\/\/(.+)?(wistia.com|wi.st)\/(medias|embed)\/.*/', 'http://fast.wistia.com/oembed', true);

// REMOVE EMOJI ICONS
remove_action('wp_head', 'print_emoji_detection_script', 7);
remove_action('wp_print_styles', 'print_emoji_styles');

// Add the following lines in the functions.php file of your current WordPress Theme:
if( version_compare ( $wp_version, '4.0' ) === -1 ) {
    // To Disable Smart Quotes for WordPress less than 4.0
    foreach( array(
        'bloginfo',
        'the_content',
        'the_excerpt',
        'the_title',
        'comment_text',
        'comment_author',
        'link_name',
        'link_description',
        'link_notes',
        'list_cats',
        'nav_menu_attr_title',
        'nav_menu_description',
        'single_post_title',
        'single_cat_title',
        'single_tag_title',
        'single_month_title',
        'term_description',
        'term_name',
        'widget_title',
        'wp_title'
    ) as $sQuote_disable_for )
    remove_filter( $sQuote_disable_for, 'wptexturize' );
}
else {
    // To Disable Smart Quotes for WordPress 4.0 or higher
    add_filter( 'run_wptexturize', '__return_false' );
}

//allow svg uploads
add_filter('upload_mimes', 'custom_upload_mimes');

function custom_upload_mimes ( $existing_mimes=array() ) {

	// add the file extension to the array

	$existing_mimes['svg'] = 'image/svg+xml';
        $existing_mimes['ps'] = 'application/postscript';


        // call the modified list of extensions

	return $existing_mimes;

}


function return_300 ( $seconds ) {
  // change the default feed cache recreation period to 2 hours
  return 300;
}
add_filter( 'wp_feed_cache_transient_lifetime' , 'return_300' );

// Search pages before posts
// This was temporarilly added to ensure pages were sorted before posts. Make things confusing
// if site has other post types -- need a better per-site solution with options.
//add_filter('posts_orderby','my_sort_custom',10,2);
function my_sort_custom( $orderby, $query ){
    global $wpdb;
    if(!is_admin() && is_search()) 
        $orderby =  $wpdb->prefix."posts.post_type ASC, {$wpdb->prefix}posts.post_date DESC";
    return  $orderby;
}


// Allow more html in content
function fb_change_mce_options($initArray) {
        $ext = 'pre[id|name|class|style],iframe[align|longdesc| name|width|height|frameborder|scrolling|marginheight| marginwidth|src]';
        if ( isset( $initArray['extended_valid_elements'] ) ) {
                $initArray['extended_valid_elements'] .= ',' . $ext;
        } else {
                $initArray['extended_valid_elements'] = $ext;
        }
        return $initArray;
}
add_filter('tiny_mce_before_init', 'fb_change_mce_options');


//Add custom styles for York theme header admin preview
add_action( 'admin_print_styles', 'load_custom_admin_css' );
function load_custom_admin_css()
{
global $theme_path;
wp_enqueue_style('yu_admin_style', $theme_path . '/yu_admin.css');
}

// Remove ?ver=x.x from css and js
function remove_cssjs_ver( $src ) {
 if( strpos( $src, '?ver=' ) )
 $src = remove_query_arg( 'ver', $src );
 return $src;
}
add_filter( 'style_loader_src', 'remove_cssjs_ver', 10, 2 );
add_filter( 'script_loader_src', 'remove_cssjs_ver', 10, 2 );

// Breadcrum functionality
function yubreadcrumbs() {
     global $options;
     $delimiter = '&raquo;&nbsp;&nbsp;';

     if ($options['breadcrumb_root_label'] == "" ) {
       $rootlink = '<a href="'.get_bloginfo('url').'">  '.get_bloginfo('name').'</a>' . $delimiter ;
     } else {
       $rootlink = '<a href="'.get_bloginfo('url').'">  '. $options['breadcrumb_root_label'].'</a>' . $delimiter ;
     }


    if (is_page() && !is_front_page() || is_single() || is_category()) {
        echo $rootlink;

        if (is_page()) {
            $ancestors = get_post_ancestors($post);

            if ($ancestors) {
                $ancestors = array_reverse($ancestors);

                foreach ($ancestors as $crumb) {
                    echo '<a href="'.get_permalink($crumb).'"> '.get_the_title($crumb).'</a>' . $delimiter;
                }
            }
        }

        if (is_single()) {
            $category = get_the_category();
            echo '<a href="'.get_category_link($category[0]->cat_ID).'"> '.$category[0]->cat_name.'</a>' . $delimiter;
        }

        if (is_category() || is_archive()) {
            $category = get_the_category();
            echo ''.$category[0]->cat_name.'' . $delimiter;
        }

        // Current page
        if (is_page() || is_single()) {
            echo ''.get_the_title().'';
        }
    } elseif (is_front_page()) {
        // Front page
        echo $rootlink . 'Home Page';
    } else {
      echo $rootlink;
      echo '<a href="'.get_bloginfo('url').'"> '.get_bloginfo('name').'</a>' . $delimiter;
      $category = get_the_category();
      echo ''.$category[0]->cat_name.'';

    }
}

/*
 * Returns height of image to be stored for use with headers
 */
function get_height($url) {
  if ($url) {
  $size = getimagesize($url);
  $height = $size[1];
  return $height;
  }
}

// Change Customize menu to York Theme Options
function edit_admin_menus() {
	global $menu;
        global $submenu;  
	$submenu['themes.php'][6][0] = 'York Theme Options';
}
add_action( 'admin_menu', 'edit_admin_menus' );



// allow widget areas to process short codes
add_filter('widget_text', 'do_shortcode');

/**
 * Sets up the content width value based on the theme's design.
 * @see twentythirteen_content_width() for template-specific adjustments.
 */
if ( ! isset( $content_width ) )
	$content_width = 604;

/**
 * Adds support for a custom header image.
 */
require( get_template_directory() . '/inc/custom-header.php' );

/**
 * Twenty Thirteen only works in WordPress 3.6 or later.
 */
if ( version_compare( $GLOBALS['wp_version'], '3.5.1-alpha', '<' ) )
	require( get_template_directory() . '/inc/back-compat.php' );

/**
 * Sets up theme defaults and registers the various WordPress features that
 * Twenty Thirteen supports.
 *
 * @uses load_theme_textdomain() For translation/localization support.
 * @uses add_editor_style() To add a Visual Editor stylesheet.
 * @uses add_theme_support() To add support for automatic feed links, post
 * formats, and post thumbnails.
 * @uses register_nav_menu() To add support for a navigation menu.
 * @uses set_post_thumbnail_size() To set a custom post thumbnail size.
 *
 * @since Twenty Thirteen 1.0
 *
 * @return void
 */
function york_twentythirteen_setup() {
	/*
	 * Makes Twenty Thirteen available for translation.
	 *
	 * Translations can be added to the /languages/ directory.
	 * If you're building a theme based on Twenty Thirteen, use a find and
	 * replace to change 'twentythirteen' to the name of your theme in all
	 * template files.
	 */
	load_theme_textdomain( 'twentythirteen', get_template_directory() . '/languages' );

	/*
	 * This theme styles the visual editor to resemble the theme style,
	 * specifically font, colors, and column width.
	 */
	add_editor_style( 'css/editor-style.css' );

	// Adds RSS feed links to <head> for posts and comments.
	add_theme_support( 'automatic-feed-links' );

	/*
	 * This theme supports all available post formats.
	 * See http://codex.wordpress.org/Post_Formats
	 *
	 * Structured post formats are formats where Twenty Thirteen handles the
	 * output instead of the default core HTML output.
	 */
	//add_theme_support( 'structured-post-formats', array(
	//	'link', 'video'
	//) );
	//add_theme_support( 'post-formats', array(
	//	'aside', 'audio', 'chat', 'gallery', 'image', 'quote', 'status'
	//) );

	// This theme uses wp_nav_menu() in one location.
	//register_nav_menu( 'primary', __( 'Navigation Menu', 'twentythirteen' ) );
        register_nav_menu( 'primary', 'Main Navigation');
        register_nav_menu( 'footer-links', 'Footer Links');
	/*
	 * This theme uses a custom image size for featured images, displayed on
	 * "standard" posts and pages.
	 */
	add_theme_support( 'post-thumbnails' );
	set_post_thumbnail_size( 604, 270, true );

	// Register custom image size for image post formats.
	add_image_size( 'twentythirteen-image-post', 724, 1288 );

	// This theme uses its own gallery styles.
	//add_filter( 'use_default_gallery_style', '__return_false' );
        //remove_theme_support('post-formats');

}
add_action( 'after_setup_theme', 'york_twentythirteen_setup');


function yu_page_menu() {
	wp_page_menu(array('menu_class' => 'nav-menu row', 'container'=>'ul'));
}

/**
 * Returns the Google font stylesheet URL, if available.
 *
 * The use of Source Sans Pro and Bitter by default is localized. For languages
 * that use characters not supported by the font, the font can be disabled.
 *
 * @since Twenty Thirteen 1.0
 *
 * @return string Font stylesheet or empty string if disabled.
 */
function york_twentythirteen_fonts_url() {
	$fonts_url = '';

	/* Translators: If there are characters in your language that are not
	 * supported by Source Sans Pro, translate this to 'off'. Do not translate
	 * into your own language.
	 */
	$source_sans_pro = _x( 'on', 'Source Sans Pro font: on or off', 'twentythirteen' );

	/* Translators: If there are characters in your language that are not
	 * supported by Bitter, translate this to 'off'. Do not translate into your
	 * own language.
	 */
	$bitter = _x( 'on', 'Bitter font: on or off', 'twentythirteen' );

	if ( 'off' !== $source_sans_pro || 'off' !== $bitter ) {
		$font_families = array();

		if ( 'off' !== $source_sans_pro )
			$font_families[] = 'Source+Sans+Pro:400,700,300italic,400italic,700italic';

		if ( 'off' !== $bitter )
			$font_families[] = 'Bitter:400,700';

		$protocol = is_ssl() ? 'https' : 'http';
		$query_args = array(
			'family' => implode( '|', $font_families ),
			'subset' => 'latin,latin-ext',
		);
		$fonts_url = add_query_arg( $query_args, "$protocol://fonts.googleapis.com/css" );
	}

	return $fonts_url;
}

/**
 * Loads our special font CSS file.
 *
 * To disable in a child theme, use wp_dequeue_style()
 * function mytheme_dequeue_fonts() {
 *     wp_dequeue_style( 'twentythirteen-fonts' );
 * }
 * add_action( 'wp_enqueue_scripts', 'mytheme_dequeue_fonts', 11 );
 *
 * Also used in the Appearance > Header admin panel:
 * @see twentythirteen_custom_header_setup()
 *
 * @since Twenty Thirteen 1.0
 *
 * @return void
 */
function york_twentythirteen_fonts() {
	$fonts_url = york_twentythirteen_fonts_url();
	if ( ! empty( $fonts_url ) )
		wp_enqueue_style( 'twentythirteen-fonts', esc_url_raw( $fonts_url ), array(), null );
}
//add_action( 'wp_enqueue_scripts', 'york_twentythirteen_fonts' );

/**
 * Adds additional stylesheets to the TinyMCE editor if needed.
 *
 * @uses twentythirteen_fonts_url() to get the Google Font stylesheet URL.
 *
 * @since Twenty Thirteen 1.0
 *
 * @param string $mce_css CSS path to load in TinyMCE.
 * @return string
 */
function york_twentythirteen_mce_css( $mce_css ) {
	$fonts_url = york_twentythirteen_fonts_url();

	if ( empty( $fonts_url ) )
		return $mce_css;

	if ( ! empty( $mce_css ) )
		$mce_css .= ',';

	$mce_css .= esc_url_raw( str_replace( ',', '%2C', $fonts_url ) );

	return $mce_css;
}
add_filter( 'mce_css', 'york_twentythirteen_mce_css' );

/**
 * Enqueues scripts and styles for front end.
 *
 * @since Twenty Thirteen 1.0
 *
 * @return void
 */
function york_twentythirteen_scripts_styles() {
	global $wp_styles;
        global $theme_path;
	/*
	 * Adds JavaScript to pages with the comment form to support sites with
	 * threaded comments (when in use).
	 */
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) )
		wp_enqueue_script( 'comment-reply' );

	// Adds Masonry to handle vertical alignment of footer widgets.
	if ( is_active_sidebar( 'sidebar-1' ) )
		wp_enqueue_script( 'jquery-masonry' );

	wp_enqueue_script( 'twentythirteen-script', get_template_directory_uri() . '/js/functions.js', array( 'jquery' ), '20130423', true );

        wp_enqueue_script("jquery-ui-button");
        wp_enqueue_script("jquery-ui-tabs");


        // ONLY LOAD SMARTMENU script if UBERMENU is not active
        //include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
        if (!is_plugin_active("ubermenu/ubermenu.php")) {
          wp_enqueue_script( 'smartmenus', get_template_directory_uri() . '/js/smartmenus-0.9.7/jquery.smartmenus.js', array( 'jquery' ), '20130423', true );
          wp_enqueue_script( 'smartmenu-script', get_template_directory_uri() . '/js/smartmenu.js', array( 'smartmenus' ), '20130423', true );
          wp_enqueue_script( 'smartmenuskeyboard', get_template_directory_uri() . '/js/smartmenus-0.9.7/addons/keyboard/jquery.smartmenus.keyboard.js', array( 'smartmenus' ), '20130423', true );
          wp_register_style( 'sm-core', get_template_directory_uri() . '/js/smartmenus-0.9.7/css/sm-core-css.css', ('google-fonts'), false, 'all' );
          wp_enqueue_style( 'sm-core' );
          wp_register_style( 'sm-theme', get_template_directory_uri() . '/js/smartmenus-0.9.7/css/sm-blue/sm-blue.css', ('sm-core'), false, 'all' );
          wp_enqueue_style( 'sm-theme' );
        }

	
        wp_enqueue_style( 'twentythirteen-ie', $theme_path . '/ie.css', array( 'twentythirteen-style' ), '20130213' );

	$wp_styles->add_data( 'twentythirteen-ie', 'conditional', 'lt IE 9' );

        wp_register_style( 'google-fonts', 'http://blog.yorku.ca/_yufonts/york_google_fonts.css', array('font-awesome'), false, 'all' );
        wp_enqueue_style( 'google-fonts' );

        wp_register_style( 'font-awesome', $theme_path . '/css/font-awesome.css', false, false, 'all' );
        wp_enqueue_style( 'font-awesome' );

        wp_register_style( 'twentythirteen-style',  get_stylesheet_uri(),  array('font-awesome'), false, 'all' );
        wp_enqueue_style( 'twentythirteen-style');

}
add_action( 'wp_enqueue_scripts', 'york_twentythirteen_scripts_styles', 0);


/**
 * Creates a nicely formatted and more specific title element text for output
 * in head of document, based on current view.
 *
 * @since Twenty Thirteen 1.0
 *
 * @param string $title Default title text for current view.
 * @param string $sep Optional separator.
 * @return string Filtered title.
 */
function york_twentythirteen_wp_title( $title, $sep ) {
	global $paged, $page;

	if ( is_feed() )
		return $title;

	// Add the site name.
	$title .= get_bloginfo( 'name' );

	// Add the site description for the home/front page.
	$site_description = get_bloginfo( 'description', 'display' );
	if ( $site_description && ( is_home() || is_front_page() ) )
		$title = "$title $sep $site_description";

	// Add a page number if necessary.
	if ( $paged >= 2 || $page >= 2 )
		$title = "$title $sep " . sprintf( __( 'Page %s', 'twentythirteen' ), max( $paged, $page ) );

	return $title;
}

add_filter('cWCdeveloperClasses','widgetclasses');

function widgetclasses(){
         $clsses['classes']=array(
            array(
                'class'=>'with-border',
                'desc'=>'With Border'

            ),
            array(
                'class'=>'white-bg',
                'desc'=>'white background'
            )
        );   

        $clsses['default']=array(       
                'class'=>'widget',      
                'desc'=>'Widget'
                );  

    return $clsses;         
}


add_filter( 'wp_title', 'york_twentythirteen_wp_title', 10, 2 );

/**
 * Registers two widget areas.
 *
 * @since Twenty Thirteen 1.0
 *
 * @return void
 */
function york_twentythirteen_widgets_init() {

       register_sidebar( array(
                'name'          => __( 'Right Sidebar Widget Area', 'twentythirteen' ),
                'id'            => 'sidebar-2',
                'description'   => __( 'Appears on posts and pages in the sidebar. Widgets flow to below content on smaller screens.', 'twentythirteen' ),
                'before_widget' => '<aside id="%1$s" class="widget %2$s">',
                'after_widget'  => '</aside>',
                'before_title'  => '<h2 class="widget-title">',
                'after_title'   => '</h2>',
        ) );

        register_sidebar( array(
                'name'          => __( 'Page Header Widget Area', 'twentythirteen' ),
                'id'            => 'sidebar-pageheader',
                'description'   => __( 'Appears on all Pages above Title.', 'twentythirteen' ),
                'before_widget' => '',
                'after_widget'  => '',
                'before_title'  => '',
                'after_title'   => '',
        ) );

        register_sidebar( array(
                'name' => __( 'Slideshow Area', 'twentythirteen' ),
                'id' => 'sidebar-8',
                'description' => __( 'Optional slideshow or static image for Home page', 'twentythirteen' ),
                'before_widget' => '',
                'after_widget' => "",
                'before_title' => '',
                'after_title' => '',
        ) );

       register_sidebar( array(
                'name' => __( 'Page Footer', 'twentythirteen' ),
                'id' => 'sidebar-9',
                'description' => __( 'Footer menu area for all pages.', 'twentythirteen' ),
                'before_widget' => '',
                'after_widget' => "",
                'before_title' => '',
                'after_title' => '',
        ) );

}
add_action( 'widgets_init', 'york_twentythirteen_widgets_init' );

if ( ! function_exists( 'twentythirteen_paging_nav' ) ) :
/**
 * Displays navigation to next/previous set of posts when applicable.
 *
 * @since Twenty Thirteen 1.0
 *
 * @return void
 */
function twentythirteen_paging_nav() {
	global $wp_query;

	// Don't print empty markup if there's only one page.
	if ( $wp_query->max_num_pages < 2 && ( is_home() || is_archive() || is_search() ) )
		return;
	?>
	<nav class="navigation paging-navigation" role="navigation">
		<h1 class="screen-reader-text"><?php _e( 'Posts navigation', 'twentythirteen' ); ?></h1>
		<div class="nav-links">

			<?php if ( get_next_posts_link() ) : ?>
			<div class="nav-previous"><?php next_posts_link( __( '<span class="meta-nav">&larr;</span> Older items', 'twentythirteen' ) ); ?></div>
			<?php endif; ?>

			<?php if ( get_previous_posts_link() ) : ?>
			<div class="nav-next"><?php previous_posts_link( __( 'Newer items <span class="meta-nav">&rarr;</span>', 'twentythirteen' ) ); ?></div>
			<?php endif; ?>

		</div><!-- .nav-links -->
	</nav><!-- .navigation -->
	<?php
}
endif;

if ( ! function_exists( 'twentythirteen_post_nav' ) ) :
/**
 * Displays navigation to next/previous post when applicable.
*
* @since Twenty Thirteen 1.0
*
* @return void
*/
function twentythirteen_post_nav() {
	global $post;

	// Don't print empty markup if there's nowhere to navigate.
	$previous = ( is_attachment() ) ? get_post( $post->post_parent ) : get_adjacent_post( false, '', true );
	$next = get_adjacent_post( false, '', false );

	if ( ! $next && ! $previous )
		return;
	?>
	<nav class="navigation post-navigation" role="navigation">
		<h1 class="screen-reader-text"><?php _e( 'Post navigation', 'twentythirteen' ); ?></h1>
		<div class="nav-links">

			<?php previous_post_link( '%link', _x( '<span class="meta-nav">&larr;</span> %title', 'Previous post link', 'twentythirteen' ) ); ?>
			<?php next_post_link( '%link', _x( '%title <span class="meta-nav">&rarr;</span>', 'Next post link', 'twentythirteen' ) ); ?>

		</div><!-- .nav-links -->
	</nav><!-- .navigation -->
	<?php
}
endif;

if ( ! function_exists( 'twentythirteen_entry_meta' ) ) :
/**
 * Prints HTML with meta information for current post: categories, tags, permalink, author, and date.
 *
 * Create your own twentythirteen_entry_meta() to override in a child theme.
 *
 * @since Twenty Thirteen 1.0
 *
 * @return void
 */
function twentythirteen_entry_meta() {
	if ( is_sticky() && is_home() && ! is_paged() )
		echo '<span class="featured-post">' . __( 'Sticky', 'twentythirteen' ) . '</span>';

	if ( ! has_post_format( 'link' ) && 'post' == get_post_type() )
		twentythirteen_entry_date();

        // Only show categories for posts if there are more than one and  
        $cats = get_the_category();
        if ('post' == get_post_type()) {  
	if (count($cats) > 1 || $cats[0]->term_id != get_option('default_category')) {
   	   // Translators: used between list items, there is a space after the comma.
	   $categories_list = get_the_category_list( __( ', ', 'twentythirteen' ) );
        
           if ( $categories_list ) {
		echo '<span class="categories-links">' . $categories_list . '</span>';
	   }
        }
	}

	// Translators: used between list items, there is a space after the comma.
	$tag_list = get_the_tag_list( '', __( ', ', 'twentythirteen' ) );
	if ( $tag_list ) {
		echo '<span class="tags-links">' . $tag_list . '</span>';
	}

	// Post author
	if ( 'post' == get_post_type() ) {
		printf( '<span class="author vcard"><a class="url fn n" href="%1$s" title="%2$s" rel="author">%3$s</a></span>',
			esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ),
			esc_attr( sprintf( __( 'View all posts by %s', 'twentythirteen' ), get_the_author() ) ),
			get_the_author()
		);
	}
}
endif;

if ( ! function_exists( 'twentythirteen_entry_date' ) ) :
/**
 * Prints HTML with date information for current post.
 *
 * Create your own twentythirteen_entry_date() to override in a child theme.
 *
 * @since Twenty Thirteen 1.0
 *
 * @param boolean $echo Whether to echo the date. Default true.
 * @return string
 */
function twentythirteen_entry_date( $echo = true ) {
	$format_prefix = ( has_post_format( 'chat' ) || has_post_format( 'status' ) ) ? _x( '%1$s on %2$s', '1: post format name. 2: date', 'twentythirteen' ): '%2$s';

	$date = sprintf( '<span class="date"><a href="%1$s" title="%2$s" rel="bookmark"><time class="entry-date" datetime="%3$s">%4$s</time></a></span>',
		esc_url( get_permalink() ),
		esc_attr( sprintf( __( 'Permalink to %s', 'twentythirteen' ), the_title_attribute( 'echo=0' ) ) ),
		esc_attr( get_the_date( 'c' ) ),
		esc_html( sprintf( $format_prefix, get_post_format_string( get_post_format() ), get_the_date() ) )
	);

	if ( $echo )
		echo $date;

	return $date;
}
endif;

/**
 * Returns the URL from the post.
 *
 * @uses get_the_link() to get the URL in the post meta (if it exists) or
 * the first link found in the post content.
 *
 * Falls back to the post permalink if no URL is found in the post.
 *
 * @since Twenty Thirteen 1.0
 * @return string URL
 */
function york_twentythirteen_get_link_url() {
	$has_url = get_the_post_format_url();

	return ( $has_url ) ? $has_url : apply_filters( 'the_permalink', get_permalink() );
}

/**
 * Sets the image size in featured galleries to large.
 *
 * @since Twenty Thirteen 1.0
 *
 * @param array $atts Combined and filtered attribute list.
 * @return array
 */
function york_twentythirteen_gallery_atts( $atts ) {
	if ( has_post_format( 'gallery' ) && ! is_single() )
		$atts['size'] = 'large';

	return $atts;
}
add_filter( 'shortcode_atts_gallery', 'york_twentythirteen_gallery_atts' );

/**
 * Extends the default WordPress body class to denote:
 * 1. Custom fonts enabled.
 * 2. Single or multiple authors.
 * 3. Active widgets in the sidebar to change the layout and spacing.
 * 4. When avatars are disabled in discussion settings.
 *
 * @since Twenty Thirteen 1.0
 *
 * @param array $classes Existing class values.
 * @return array Filtered class values.
 */
function york_twentythirteen_body_class( $classes ) {
        global $options;
        $horizontal_nav = $options['horizontal_nav'];
        //$darktheme = $options['dark_theme'];

	// Enable custom font class only if the font CSS is queued to load.
	if ( wp_style_is( 'twentythirteen-fonts', 'enqueued' ) )
		$classes[] = 'custom-font';

	if ( ! is_multi_author() )
		$classes[] = 'single-author';
       
        // Add sidebar class if there is a sidebar or 
	if ( (is_active_sidebar('sidebar-2') || yusocial("")>"" ) && ! is_attachment() )
		$classes[] = 'sidebar';

	if ( ! get_option( 'show_avatars' ) )
		$classes[] = 'no-avatars';

        //if ( $darktheme )
        //        $classes[] = 'darktheme';

            $classes[] = 'horizontal_nav';

	return $classes;
}
add_filter( 'body_class', 'york_twentythirteen_body_class' );

/**
 * Adjusts content_width value for video post formats and attachment templates.
 *
 * @since Twenty Thirteen 1.0
 *
 * @return void
 */
function york_twentythirteen_content_width() {
	if ( has_post_format( 'video' ) || is_attachment() ) {
		global $content_width;
		$content_width = 724;
	}
}
add_action( 'template_redirect', 'york_twentythirteen_content_width' );

/**
 * Adjusts content_width value for video shortcodes in video post formats.
 *
 * @since Twenty Thirteen 1.0
 *
 * @param array $atts Attribute list.
 * @return array Filtered attribute list.
 */
function york_twentythirteen_video_width( $atts ) {
	if ( ! is_admin() && has_post_format( 'video' ) ) {
		$new_width = 724;
		$atts['height'] = round( ( $atts['height'] * $new_width ) / $atts['width'] );
		$atts['width'] = $new_width;
	}

	return $atts;
}
add_action( 'embed_defaults',       'york_twentythirteen_video_width' );
add_action( 'shortcode_atts_video', 'york_twentythirteen_video_width' );

/**
 * Switches default core markup for search form to output valid HTML5.
 *
 * @param string $format Expected markup format, default is `xhtml`
 * @return string Twenty Thirteen loves HTML5.
 */
function york_twentythirteen_search_form_format( $format ) {
	return 'html5';
}
add_filter( 'search_form_format', 'york_twentythirteen_search_form_format' );

/**
 * Add postMessage support for site title and description for the Customizer.
 *
 * @since Twenty Thirteen 1.0
 *
 * @param WP_Customize_Manager $wp_customize Customizer object.
 * @return void
 */
function york_twentythirteen_customize_register( $wp_customize ) {
	$wp_customize->get_setting( 'blogname' )->transport         = 'postMessage';
	$wp_customize->get_setting( 'blogdescription' )->transport  = 'postMessage';
        $wp_customize->remove_section( 'colors' );

	//$wp_customize->get_setting( 'header_textcolor' )->transport = 'postMessage';
	//$wp_customize->add_setting( 'horizontal_nav' , array('default' => false, 'transport' => 'refresh'));



// Add Post Settings for Date display, etc
$wp_customize->add_section('yu_post_settings', array( 'title' => __('Theme Options','york_twentythirteen'), 'capability' => 'edit_theme_options', 'priority' => 400,));

$wp_customize->add_setting(
	'york_twentythirteen_options[layout_setting]', array(
	'default' => 'postdate_option',
	'capability' => 'edit_theme_options',
	'type' => 'option'
	)
);

$wp_customize->add_control('display_postdate_option', array(
        'settings' => 'york_twentythirteen_options[layout_setting]',
        'label'    => __('Hide Post Dates?'),
        'section'  => 'yu_post_settings',
        'type'     => 'checkbox',
));

// SOCIAL MEDIA
$wp_customize->add_section('yu_social_media', array( 'title' => __('Social Media Options','york_twentythirteen'), 'capability' => 'edit_theme_options', 'priority' => 300,));

// FACEBOOK URL
$wp_customize->add_setting(
        'york_twentythirteen_options[facebook_url]', array(
        'default' => $facebook_url,
        'capability' => 'edit_theme_options',
        'type' => 'option'
        )
);

$wp_customize->add_control('display_facebook_option', array(
        'settings' => 'york_twentythirteen_options[facebook_url]',
        'label'    => __('Facebook URL'),
        'section'  => 'yu_social_media',
        'type'     => 'text',
));

//TWITTER URL
$wp_customize->add_setting(
        'york_twentythirteen_options[twitter_url]', array(
        'default' => $twitter_url,
        'capability' => 'edit_theme_options',
        'type' => 'option'
        )
);

$wp_customize->add_control('display_twitter_option', array(
        'settings' => 'york_twentythirteen_options[twitter_url]',
        'label'    => __('Twitter URL'),
        'section'  => 'yu_social_media',
        'type'     => 'text',
));

//INSTAGRAM
$wp_customize->add_setting(
        'york_twentythirteen_options[instagram_url]', array(
        'default' => "",
        'capability' => 'edit_theme_options',
        'type' => 'option'
        )
);

$wp_customize->add_control('display_instgram_option', array(
        'settings' => 'york_twentythirteen_options[instagram_url]',
        'label'    => __('Instagram URL'),
        'section'  => 'yu_social_media',
        'type'     => 'text',
));

// LINKEDIN URL
$wp_customize->add_setting(
        'york_twentythirteen_options[linkedin_url]', array(
        'default' => '',
        'capability' => 'edit_theme_options',
        'type' => 'option'
        )
);

$wp_customize->add_control('display_linkedin_option', array(
        'settings' => 'york_twentythirteen_options[linkedin_url]',
        'label'    => __('LinkedIn URL'),
        'section'  => 'yu_social_media',
        'type'     => 'text',
));

// YOUTUBE URL
$wp_customize->add_setting(
        'york_twentythirteen_options[youtube_url]', array(
        'default' => $youtube_url,
        'capability' => 'edit_theme_options',
        'type' => 'option'
        )
);

$wp_customize->add_control('display_youtube_option', array(
        'settings' => 'york_twentythirteen_options[youtube_url]',
        'label'    => __('YouTube URL'),
        'section'  => 'yu_social_media',
        'type'     => 'text',
));

// FLICKR URL
$wp_customize->add_setting(
        'york_twentythirteen_options[flickr_url]', array(
        'default' => $flickr_url,
        'capability' => 'edit_theme_options',
        'type' => 'option'
        )
);

$wp_customize->add_control('display_flickr_option', array(
        'settings' => 'york_twentythirteen_options[flickr_url]',
        'label'    => __('Flickr URL'),
        'section'  => 'yu_social_media',
        'type'     => 'text',
));

// RSS Link
$wp_customize->add_setting(
        'york_twentythirteen_options[rss_url]', array(
        'default' => $rss_url,
        'capability' => 'edit_theme_options',
        'type' => 'option'
        )
);

$wp_customize->add_control('display_rss_option', array(
        'settings' => 'york_twentythirteen_options[rss_url]',
        'label'    => __('RSS URL'),
        'section'  => 'yu_social_media',
        'type'     => 'text',
));


// YFILE Link
$wp_customize->add_setting(
        'york_twentythirteen_options[yfile_link]', array(
        'default' => '',
        'capability' => 'edit_theme_options',
        'type' => 'option'
        )
);

$wp_customize->add_control('display_yfile_option', array(
        'settings' => 'york_twentythirteen_options[yfile_link]',
        'label'    => __('Show Yfile Link'),
        'section'  => 'yu_social_media',
        'type'     => 'checkbox'
));

$wp_customize->add_setting( 'york_twentythirteen_options[site_link]', array('default' => get_site_url(), 'type'=>'option', 'transport' => 'refresh' ));
$wp_customize->add_control('set_site_link', array(
        'settings' => 'york_twentythirteen_options[site_link]',
        'label'    => __('Site Link'),
        'section'  => 'title_tagline',
        'type'     => 'text',
        'priority' => 1  
));

$wp_customize->add_setting( 'york_twentythirteen_options[dept_link]', array('default' => '', 'type'=>'option', 'transport' => 'refresh' ));
$wp_customize->add_control('set_dept_link', array(
        'settings' => 'york_twentythirteen_options[dept_link]',
        'label'    => __('Department Link'),
        'section'  => 'title_tagline',
        'type'     => 'text',
        'priority' => 10 
));


$wp_customize->add_setting( 'york_twentythirteen_options[post_featured_images]', array('default' => false, 'type'=>'option', 'transport' => 'postMessage' ));
$wp_customize->add_control('use_post_featured_images', array(
        'settings' => 'york_twentythirteen_options[post_featured_images]',
        'label'    => __('Use Featured Images on Posts?'),
        'section'  => 'yu_post_settings',
        'type'     => 'checkbox',
        'priority' => 2
));


$wp_customize->add_setting( 'york_twentythirteen_options[breadcrumb]', array('default' => false, 'type'=>'option', 'transport' => 'refresh' ));
$wp_customize->add_control('use_breadcrumb', array(
        'settings' => 'york_twentythirteen_options[breadcrumb]',
        'label'    => __('Use Breadcrumbs?'),
        'section'  => 'yu_post_settings',
        'type'     => 'checkbox',
        'priority' => 3
));

$wp_customize->add_setting( 'york_twentythirteen_options[breadcrumb_root_label]', array('default' => '', 'type'=>'option', 'transport' => 'refresh' ));
$wp_customize->add_control('use_breadcrumb_root_label', array(
        'settings' => 'york_twentythirteen_options[breadcrumb_root_label]',
        'label'    => __('Breadcrumb Root Label'),
        'default'  => '',
        'section'  => 'yu_post_settings',
        'type'     => 'text',
        'priority' => 4
));

$wp_customize->add_setting( 'york_twentythirteen_options[slider_allpages]', array('default' => false, 'type'=>'option', 'transport' => 'refresh' ));
$wp_customize->add_control('use_slider_allpages', array(
        'settings' => 'york_twentythirteen_options[slider_allpages]',
        'label'    => __('Slideshow widget on all pages?'),
        'section'  => 'yu_post_settings',
        'type'     => 'checkbox',
        'priority' => 5
));

$wp_customize->add_setting( 'york_twentythirteen_options[yu_social_html]', array('default' => "", 'type'=>'option', 'transport' => 'refresh' ));
$wp_customize->add_control('yu_social_html', array(
        'settings' => 'york_twentythirteen_options[yu_social_html]',
        'label'    => __('HTML'),
        'default'  => yusocial(''),
        'section'  => 'yu_social_media',
        'type'     => 'text',
        'priority' => 50 
));



}


// Change Labels
add_filter( 'gettext', 'theme_change_label_names', 20,3 );
add_filter( 'ngettext', 'theme_change_label_names', 20,3 );

function theme_change_label_names($translated_text, $text, $domain){
    if (is_admin()){
        switch ( $translated_text ) {

            case 'Site Title & Tagline' :
                $translated_text = 'Site & Department/Unit';
                break;

            case 'Site Title' :
                $translated_text = 'Site';
                break;
            case 'Tagline' :
                $translated_text = 'Department/Unit';
                break;
        }
    }
    return $translated_text;
}


function yusocial($atts) {
  global $options;
  $fb="";
  $tw="";
  $ig="";
  $ln="";
  $ytube="";
  $flickr="";
  $yrss="";
  $yf="";
  $hs=false;   
  if ($options['yfile_link']) {
     $hs=true;
     $yf = '<div class="sm-link-box"><a class="yfile-link" href="http://yfile.news.yorku.ca/"><i class="fa yfile-icon yuicons"></i><span class="accessible">yfile</span></a></div>';
  }
   if (!empty($options['facebook_url'])) {
     $hs=true;
     $fb = '<div class="sm-link-box"><a href="' . $options['facebook_url'] . '"><i class="fa fa-facebook yuicons"></i><span class="accessible">facebook</span></a></div>';
   } else { $fb =""; }

   if (!empty($options['twitter_url'])) {
     $hs=true;
     $tw = '<div class="sm-link-box"><a href="' . $options['twitter_url'] . '"><i class="fa fa-twitter yuicons"></i><span class="accessible">twitter</span></a></div>';
   } else { $tw =""; }

   if (!empty($options['instagram_url'])) {
     $hs=true;
     $ig = '<div class="sm-link-box"><a href="' . $options['instagram_url'] . '"><i class="fa fa-instagram yuicons"></i><span class="accessible">instagram</span></a></div>';
   } else { $ig =""; }

   if (!empty($options['flickr_url'])) {
     $hs=true;
     $flickr = '<div class="sm-link-box"><a href="' . $options['flickr_url'] . '"><i class="fa fa-flickr  yuicons"></i><span class="accessible">flickr</span></a></div>';
   } else { $flickr =""; }

   if (!empty($options['youtube_url'])) {
     $hs=true;
     $ytube = '<div class="sm-link-box"><a href="' . $options['youtube_url'] . '"><i class="fa fa-youtube yuicons"></i><span class="accessible">youtube</span></a></div>';
   } else { $ytube =""; }

   if (!empty($options['linkedin_url'])) { 
     $hs=true;
     $ln = '<div class="sm-link-box"><a href="' . $options['linkedin_url'] . '"><i class="fa fa-linkedin yuicons"></i><span class="accessible">linkedin</span></a></div>';
   } else { $ln =""; }

   if (!empty($options['rss_url'])) { 
     $hs=true;
     $yrss = '<div class="sm-link-box"><a href="' . $options['rss_url'] . '"><i class="fa fa-rss yuicons"></i><span class="accessible">rss</span></a></div>';
   } else { $yrss =""; }
   
   if ($hs) {
     return "<aside id=\"text-99\" class=\"widget widget_text\"><div class=\"textwidget\">" .
     "<div id='link_buttons'>" . $fb . $tw . $ig . $ln . $ytube. $flickr . $yrss . $yf . "</div>" .
     "</div></aside>";
   } else {
      return "";
   }

}
add_shortcode('yusocial', 'yusocial');


//Shortcode to return a standard York Button
function yubutton($atts) {
   extract(shortcode_atts(array(
      'link' => "",
      'text' => "York <br />University",
      'class' => "yubuttons",
      'colour' => "",
      'id' => ""
   ), $atts));
/*
//$tbutton = '<div class="'. $class .'"><a href="'. $link .'"><button>';
//if ($img<>"") { $tbutton = $tbutton . '<img src="'. $img  .'" width="'. $width .'" height="'. $height .'" />'; }
//$tbutton = $tbutton . $text . '</button></a></div>';
*/

$thisID="";
$thisColour="";
if ($id <> "")         $thisID = " id='" . $id . "' ";
if ($colour <> "") $thisColour = " class='" . $colour . "' ";
   if ($link <> "") {
      $tbutton = '<button ' . $thisID . $thisColour . ' onclick="javascript:location.href=\'' . $link . '\'">' . $text . '</button>';
   } else {
      $tbutton = '<button ' . $thisID . $thisColour . '>' . $text . '</button>';
   }

return $tbutton;
}
add_shortcode('yubutton', 'yubutton');

//Shortcode made by Alexis for Google Apps
function yugoogleapps($atts) {
   extract(shortcode_atts(array(
      'link' => "http://google.info.yorku.ca/",
      'text' => "Make the move to<br />Google Apps",
      'class' => "google-apps-btn"
   ), $atts));

$tbutton = '
<button class="google-apps-btn" onclick="window.location.href=\'http://google.info.yorku.ca/\'" ><p style="background:#e31837;color:#ffffff;font-size:1.4em;padding: 10px; margin: 20px 0 10px;">York U Undergrads<br />have gone Google<br /></p><div class=""><img alt="Google Apps Icons"  src="http://www.yorku.ca/yorkweb/demos/buttons/google-apps/GoogleMail_bg.gif" /></div></button>';
return $tbutton;
}
add_shortcode('yugoogleapps', 'yugoogleapps');

// end google apps shortcode


//Shortcode made by Alexis
function nssebtn($atts) {
   extract(shortcode_atts(array(
      'link' => "http://nsse.info.yorku.ca/",
      'text' => "Take the<br />NSSE Survey",
      'class' => "nsse-btn",
      'img' => "",
      'width' => 15,
      'height' => 15,
   ), $atts));

$tbutton = '
<button onclick="window.location.href=\'http://nsse.info.yorku.ca/\'" class="nsse-btn">Take the<br /> NSSE Survey</button>';
return $tbutton;
}
add_shortcode('nssebtn', 'nssebtn');

// Tuition Contest Shortcode
function tuitionbtn($atts) {
  $tbutton = '<button class="mh-btn" onclick="window.location.href=\'http://mytime.yorku.ca/contest/\'">enter for a chance <br />to win <span style="font-weight:bold;">FREE</span> tuition </strong></button>';
  return $tbutton;
}
add_shortcode('tuitionbtn', 'tuitionbtn');
// end Tuition Button

//Shortcode made by Alexis End

// Shortcodes to get image URLs and thumnails
function yu_image_url($atts, $value){
  global $post;
  return $post->guid;
}
add_shortcode('yu-image-url', 'yu_image_url');

function yu_thumbnail_url($atts, $value) {
  global $post;
  $thumb = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'thumbnail' );
  $url = $thumb['0'];
  return $url;
}
add_shortcode('yu-thumbnail-url', 'yu_thumbnail_url');

add_action( 'customize_register', 'york_twentythirteen_customize_register' );

/**
 * Binds JavaScript handlers to make Customizer preview reload changes
 * asynchronously.
 *
 * @since Twenty Thirteen 1.0
 */
function york_twentythirteen_customize_preview_js() {
     //update_option('yu_social_html', yusocial(''));
     wp_enqueue_script( 'twentythirteen-customizer', get_template_directory_uri() . '/js/theme-customizer.js', array( 'customize-preview' ), '20130226', true );
}
add_action( 'customize_preview_init', 'york_twentythirteen_customize_preview_js' );

//Setup Admin Widgets

add_action('wp_dashboard_setup', 'my_dashboard_widgets');
function my_dashboard_widgets() {
     global $wp_meta_boxes;
     // remove unnecessary widgets
     // var_dump( $wp_meta_boxes['dashboard'] ); // use to get all the widget IDs
     unset(
          $wp_meta_boxes['dashboard']['normal']['core']['dashboard_plugins'],
          $wp_meta_boxes['dashboard']['side']['core']['dashboard_secondary'],
          $wp_meta_boxes['dashboard']['side']['core']['dashboard_primary']
     );
     // add a custom dashboard widget
     wp_add_dashboard_widget( 'dashboard_custom_feed', 'WordPress @ York News', 'dashboard_custom_feed_output' ); //add new RSS feed output
}
function dashboard_custom_feed_output() {
     echo '<div class="rss-widget">';
     wp_widget_rss_output(array(
          'url' => 'http://wordpress.info.yorku.ca/feed/',
          'title' => 'WordPress @ York News',
          'items' => 5,
          'show_summary' => 1,
          'show_author' => 1,
          'show_date' => 1
     ));
     echo "</div>";
}
?>
