<?php
/**
 * The Header for our theme.
 *
 * Displays all of the <head> section and everything up till <div id="main">
 *
 * @package WordPress
 * @subpackage Twenty_Thirteen
 * @since Twenty Thirteen 1.0
 */

/*
 * Add class to allow styling for toolbar.
 */
$html_class = ( is_admin_bar_showing() ) ? 'wp-toolbar' : '';
?><!DOCTYPE html>
<!--[if IE 7]>
<html class="ie ie7 <?php echo $html_class; ?>" <?php language_attributes(); ?>>
<![endif]-->
<!--[if IE 8]>
<html class="ie ie8 <?php echo $html_class; ?>" <?php language_attributes(); ?>>
<![endif]-->
<!--[if !(IE 7) | !(IE 8)  ]><!-->
<html class="<?php echo $html_class; ?>" <?php language_attributes(); ?>>
<!--<![endif]-->
<head>
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta charset="<?php bloginfo( 'charset' ); ?>" />
<meta name="viewport" content="width=device-width" />
<title><?php wp_title( '|', true, 'right' ); ?></title>
<link rel="shortcut icon" href="<?php echo get_stylesheet_directory_uri(); ?>/favicon.ico" />
<!--[if lt IE 9]>
<script src="<?php echo get_template_directory_uri(); ?>/js/html5.js" type="text/javascript"></script>
<![endif]-->
<?php
//global options retrieved in functions.php
global $options;
wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<!-- Google Tag Manager -->
<noscript><iframe src="//www.googletagmanager.com/ns.html?id=GTM-WB2S8R"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'//www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-WB2S8R');</script>
<!-- End Google Tag Manager -->
<div id="page" class="hfeed site">
<header id="masthead" role="banner"><div class="yeb11skipnav"><a href="#content">Skip to main content</a><a href="#navbar">Skip to local navigation</a></div>

<!-- 2011 YORK EXTERNAL BANNER - html code -->
<div id="yeb11banner">
<div class="york-logo-holder"><a href="http://yorku.ca"><img class="yorklogo" src="http://www.yorku.ca/yorkweb/demos/test-header/images/yorku-logo-rgb-240-122.jpg" border="0" alt="York University" /></a></div
>

<button class="button quick-links" id="ql-button">Quick Links <i class="fa fa-caret-up"></i></button>
<div id="quick-links-container" >  

<div class="mobile-quicklinks-btns">
<div class="col4"><button onclick="javascript:location.href='http://www.library.yorku.ca/web/'" class="header-btn"><i class="fa fa-book"></i> Libraries</button></div>
    <div class="col4"><button onclick="javascript:location.href='http://atlas.yorku.ca'" class="header-btn"><i class="fa fa-binoculars"></i> Directory</button></div>
        <div class="col4"><button onclick="javascript:location.href='http://maps.info.yorku.ca/'" class="header-btn"><i class="fa fa-map-marker"></i> Campus Maps</button></div>
       <div class="clear"></div>        
        <ul class="menu">
       <div class="col4">  <li><a href="http://futurestudents.yorku.ca/"><span data-title="Future Students">Future Students</span></a></li>
         <li class="mobile-quicklinks-cs"><a href="http://currentstudents.yorku.ca"><span data-title="Current Students">Current Students</span></a></li></div>
         <div class="col4"><li><a href="http://alumniandfriends.yorku.ca"><span data-title="Alumni & Friends">Alumni & Friends</span></a></li></div>
       </ul>

       <div class="clear"></div>
    </div>
  
<?php include 'quick-links.inc'; ?>

    <div class="clear"></div>
</div>
<div class="greyed-page"></div>

<div id="yorklinks" class="nav-collapse">
     <div id="yorklinks-container">
     <div class="col4">

     <form id="main-search" class="main-search" method="get" action="http://search2.info.yorku.ca">
     <fieldset class="header-search">
     <legend class="accessible">Global Search</legend>
     <label for="yeb13searchfield" class="accessible">search box</label>
        <input class="header-search" type="search" name="q" maxlength="255" id="yeb13searchfield" value="Search yorku.ca"  onclick="if (!this.cleared) { this.cleared = true; this.value = ''; }" />
        <input type="hidden" name="client" value="External" />
        <input type="hidden" name="proxystylesheet" value="External" />
        <input type="hidden" name="site" value="default_collection" />
        <input type="hidden" name="output" value="xml_no_dtd" />
        </fieldset>
        <button type="submit" class="search-button"><div class="fa fa-search"></div><span class="accessible">search button</span></button>
           <button type="button" class="search-button2" onclick="window.location.href='#mobile-search'"><div class="icon-search icon-medium"></div><span class="accessible">search button</span></button>


    </form>

     <div class="menu2-new">
        <ul class="menu">
         <li><a class="roll-link ie1" href="http://futurestudents.yorku.ca/"><span data-title="Future Students">Future Students</span></a></li>
         <li><a class="roll-link ie2" href="http://www.yorku.ca/yorkweb/cs.htm"><span data-title="Current Students">Current Students</span></a></li>
         <li><a class="roll-link ie3" href="http://alumniandfriends.yorku.ca"><span data-title="Alumni & Friends">Alumni & Friends</span></a></li>
       </ul>
     </div><div class="clear"></div>
        </div>

  </div>
</div>

</div>
<!-- yeb11banner -->
<!-- end of 2014 YORK EXTERNAL BANNER - html code 3-7-13 -->


     <div class="short-banner"><hgroup><a href="<?php echo $options['site_link'];?>"><h1 class="site-title"><?php bloginfo( 'name' ); ?></h1></a>
     <?php 
     $yu_dept = get_bloginfo("description");
     if ( $yu_dept > '' ) { ?>
       <div class="dept-sub"><a href="<?php echo $options['dept_link'];?>" style="color:#ffffff;border:none;display:block;"><h2 class="dept-title"><?php echo $yu_dept; ?></a></h2></div>
     <?php } ?>
     </hgroup></div>
     <?php
     if ( has_nav_menu( 'primary' ) ) { ?>
        <div id="navbar" class="navbar">
        <nav id="site-navigation" class="navigation main-navigation horizontal-menu" role="navigation">
            <span tabindex="0" class="menu-toggle"><?php _e( 'Menu', 'twentythirteen' ); ?></span>
            <?php wp_nav_menu( array( 'theme_location' => 'primary', 'menu_id' => 'yu-smartmenu', 'menu_class' => 'sm sm-blue nav-menu row') ); ?>
            <?php //wp_nav_menu( array( 'theme_location' => 'primary', 'menu_class' => 'sm sm-blue nav-menu row') ); ?>

        </nav><!-- #site-navigation -->
        </div><!-- #navbar -->
     <?php } else { ?>
        <div id="navbar" class="navbar">
        </div>
     <?php } ?>
     <?php global $options;
     if (is_front_page() || $options['slider_allpages'] == 1) dynamic_sidebar( 'sidebar-8' ); ?><!--Slideshow Widget-->
</header><!-- #masthead -->
<div id="main" class="site-main">
