<?php
/**
 * The template for displaying the footer.
 *
 * Contains footer content and the closing of the
 * #main and #page div elements.
 *
 * @package WordPress
 * @subpackage Twenty_Thirteen
 * @since Twenty Thirteen 1.0
 */
?>
</div><!-- #main -->
<div style="clear:both"></div>
<footer id="colophon" class="site-footer" role="contentinfo">

<?php if ( is_active_sidebar( 'sidebar-9' ) ) : ?>
   <?php dynamic_sidebar( 'sidebar-9' ); ?>
<?php endif; ?>

 <div class="site-info">

<?php wp_nav_menu(array('theme_location' => 'footer-links', 'container'=>'div', 'menu_id' => 'footerlinks', 'menu_id' => 'row', 'fallback_cb' => false)); ?>
                        </div><!-- .site-info -->
		</footer><!-- #colophon -->
	<div class="york-global-footer-links"><ul>
	<li><a href="http://site.info.yorku.ca/site-index/">Site Index</a></li>
	<li><a href="http://site.info.yorku.ca/privacy-legal/">Privacy &amp; Legal</a></li>
	<li><a href="http://about.yorku.ca/careers/">Careers</a></li>
	<li><a href="http://site.info.yorku.ca/">Contact York University</a></li>
	</ul></div>	


<form id="mobile-search" class="main-search" method="get" action=" http://search.yorku.ca/search ">
     <fieldset class="header-search">
     <legend class="accessible">Global Search</legend>
     <label for="yeb13searchfield2" class="accessible">search box</label>
<input class="header-search" type="search" name="q" maxlength="255" id="yeb13searchfield2" value="Search yorku.ca "  onclick="if (!this.cleared) { this.cleared = true; this.value = ''; }" />
  <input type="hidden" name="client" value="External" />
  <input type="hidden" name="proxystylesheet" value="External" />
  <input type="hidden" name="site" value="default_collection" />
  <input type="hidden" name="output" value="xml_no_dtd" />
  </fieldset>
        <button type="submit" class="search-button"><div class="icon-search icon-medium"></div><span class="accessible">search button</span></button>
        <button type="submit" class="search-button2"><div class="icon-search icon-medium"></div><span class="accessible">search button</span></button>
 </form>

</div>

<!-- #page -->
<?php wp_footer(); ?>
<?

$current_user = wp_get_current_user();
if ($current_user->user_login == 'rodp') {
 echo '<div style="clear:both;text-align:right">';
 echo get_num_queries() . " queries.  ";
 timer_stop(1);
 echo ' seconds.';
 echo '</div>';
}

?>
</body>
</html>