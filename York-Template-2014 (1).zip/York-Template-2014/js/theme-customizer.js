/**
 * Theme Customizer enhancements for a better user experience.
 *
 * Contains handlers to make Theme Customizer preview reload changes asynchronously.
 * Things like site title and description changes.
 */

( function( $ ) {
	// Site title and description.
	wp.customize( 'blogname', function( value ) {
		value.bind( function( to ) {
			$( '.site-title' ).text( to );
		} );
	} );
	wp.customize( 'blogdescription', function( value ) {
		value.bind( function( to ) {
			$( '.site-description' ).text( to );
		} );
	} );

/*
        wp.customize( 'york_twentythirteen_options[horizontal_nav]', function( value ) {
           value.bind( function( to ) {
		if (to==true) {
			//Horiztonal
			jQuery("body").removeClass("left_nav");
			jQuery("body").addClass("horizontal_nav");
			//jQuery("#masthead:nth-child(0)").prependTo('#navbar');
        		//jQuery("div.short-banner").prependTo('#navbar');
			//jQuery('#navbar').prependTo('div.short-banner');
		 //	jQuery('#navbar').appendTo('div.short-banner');

			jQuery("#masthead:nth-child(1)").prependTo('#navbar');



		} else {
			//Vertical
			jQuery("body").removeClass("horizontal_nav");
                        jQuery("body").addClass("left_nav");
			jQuery('#navbar').appendTo('#masthead');
			
		}
           });
        } );

*/
       // change theme color
       wp.customize( 'york_twentythirteen_options[dark_theme]', function( value ) {
	        value.bind( function( newval ) {
                if (newval == true) {
		    //Do stuff (newval variable contains your "new" setting data)a
                    $("body").addClass("darktheme");
                } else {
                    $("body").removeClass("darktheme");
                }
	        });
        } );


       // Use Breadcrumbs or not
       wp.customize( 'york_twentythirteen_options[breadcrumb]', function( value ) {
                value.bind( function( newval ) {
                if (newval == true) {
                    $("#yubreadcrumbs").show();
                } else {
                    $("#yubreadcrumbs").hide();
                }
                });
        } );



	// Header text color.
	wp.customize( 'header_textcolor', function( value ) {
		value.bind( function( to ) {
			if ( 'blank' == to ) {
				if ( 'remove-header' == _wpCustomizeSettings.values.header_image )
					$( '.home-link' ).css( 'min-height', '0' );
				$( '.site-title, .site-description' ).css( {
					'clip': 'rect(1px, 1px, 1px, 1px)',
					'position': 'absolute'
				} );
			} else {
				$( '.home-link' ).css( 'min-height', '230px' );
				$( '.site-title, .site-description' ).css( {
					'clip': 'auto',
					'color': to,
					'position': 'relative'
				} );
			}
		} );
	} );
} )( jQuery );
