<?php
/**
 * The template for displaying all pages.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that other
 * 'pages' on your WordPress site will use a different template.
 *
 * @package WordPress
 * @subpackage Twenty_Thirteen
 * @since Twenty Thirteen 1.0
 */

get_header(); ?>

<?php
global $options;
if ($options['breadcrumb']) {
  echo '<div id="yubreadcrumbs">';
  yubreadcrumbs();
  echo "</div>";
}
?>
<div id="primary" class="content-area">
<div id="content" class="site-content" role="main">
   <article class="page type-page status-publish hentry">
   <header class="entry-header">
<h1 class="page-title"><?php _e( 'Page not found', 'twentythirteen' ); ?></h1>
</header><!-- .entry-header -->
<div class="entry-content">
<?php
   if ( is_active_sidebar( 'sidebar-pageheader' ) ) : ?>
        <div class="">
          <?php dynamic_sidebar( 'sidebar-pageheader' ); ?>
        </div><!-- .widget-area -->
<?php endif; ?>
<p><?php _e( '<span class="error404"><br />It looks like nothing was found at this location. Maybe try a search?</span>', 'twentythirteen' ); ?></p>
</div><!-- .entry-content -->
<footer class="entry-meta">
</footer><!-- .entry-meta -->
</article><!-- #post -->
</div><!-- #content -->
</div><!-- #primary -->
<?php get_sidebar(); ?>
<?php get_footer(); ?>
